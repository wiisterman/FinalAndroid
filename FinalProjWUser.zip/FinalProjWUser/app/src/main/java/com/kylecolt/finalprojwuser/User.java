package com.kylecolt.finalprojwuser;

import java.io.Serializable;
import java.util.ArrayList;

public class User implements Serializable
{

    private String username;
    //String password;
    private Stats score;
    private ArrayList<Question> uQuestions;

    public User(String username, Stats score, ArrayList<Question> uQuestions) {
        this.username = username;
        this.score = score;
        this.uQuestions = uQuestions;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Stats getScore() {
        return score;
    }

    public void setScore(Stats score) {
        this.score = score;
    }

    public ArrayList<Question> getuQuestions() {
        return uQuestions;
    }

    public void setuQuestions(ArrayList<Question> uQuestions) {
        this.uQuestions = uQuestions;
    }

    @Override
    public String toString() {
        return "User{" +
                "username='" + username + '\'' +
                 score +
                ", uQuestions=" + uQuestions +
                '}';
    }
}
