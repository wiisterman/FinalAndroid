package com.kylecolt.finalprojwuser;


import java.util.ArrayList;
import java.util.Random;

public class QuestionBag
{


    ArrayList<Question> qArray = new ArrayList<>();

    public void add(Question s) {
        qArray.add(s);
    }

    public Question search(String id) {
        String found = "Object Not Found!";

        for (int i = 0; (i < qArray.size()); i++) {
            if (id.equals(qArray.get(i).getId())) {
                return qArray.get(i);
            }
        }

        return null;
    }

    public Question removeQ(String id) {
        int i = 0;
        for (Question s : qArray) {
            if (s.getId().equals(id)) {
                break;
            }
            i++;
        }
        if (i < qArray.size()) {
            return qArray.remove(i);
        }
        return null;

    }

    public String displayQ() {
        String test = "";
        for (int i = 0; i < qArray.size(); i++) {
            test += (qArray.get(i) + "\n");
        }

        return test;
    }


}
